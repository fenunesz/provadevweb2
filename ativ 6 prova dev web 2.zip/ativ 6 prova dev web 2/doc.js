const mysql = require('mysql2');
require('dotenv').config();

const connection = mysql.createConnection({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'fatec123',
  database: process.env.DB_NAME || 'aaaaa'
});

connection.connect((err) => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados:', err);
  } else {
    console.log('Conectado ao banco de dados MySQL');
  }
});

const gravarAluno = (id, nome, email) => {
  const query = 'INSERT INTO aluno (id, nome, email) VALUES (?, ?, ?)';
  connection.query(query, [id, nome, email], (err, result) => {
    if (err) {
      console.error('Erro ao inserir aluno:', err);
    } else {
      console.log('Aluno inserido com sucesso:', result);
    }
  });
};

const buscarAlunos = () => {
  const query = 'SELECT id, nome, email FROM aluno';
  connection.query(query, (err, results) => {
    if (err) {
      console.error('Erro ao buscar alunos:', err);
    } else {
      console.log('Alunos encontrados:');
      results.forEach((aluno) => {
        console.log(`ID: ${aluno.id}, Nome: ${aluno.nome}, Email: ${aluno.email}`);
      });
    }
  });
};

gravarAluno(1, 'João Silva', 'joao.silva@email.com');
gravarAluno(2, 'Maria Santos', 'maria.santos@email.com');

buscarAlunos();

connection.end();
