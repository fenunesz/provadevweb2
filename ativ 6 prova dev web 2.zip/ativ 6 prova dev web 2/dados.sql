CREATE DATABASE aaaaa
    use aaaaa

CREATE TABLE aluno (
  id INT PRIMARY KEY,
  nome VARCHAR(100),
  email VARCHAR(100)
);